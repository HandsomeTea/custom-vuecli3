import { createApp } from 'vue';
import app from '@/App.vue';
import router from '@/router';
import store from '@/store';
import i18n from '@/lang';
import { UILibraryComponents } from '@/ui-frame';
import '@/assets';

const application = createApp(app)
	.use(store)
	.use(router)
	.use(i18n);

application.config.performance = true;
application.config.errorHandler = async (error: unknown /*, instance?: ComponentPublicInstance*/) => {
	if (process?.env?.NODE_ENV === 'development') {
		// eslint-disable-next-line no-console
		console.error(error);
	}
};
application.config.warnHandler = (msg: string /*, instance?: ComponentPublicInstance*/) => {
	if (process?.env?.NODE_ENV === 'development') {
		// eslint-disable-next-line no-console
		console.warn(msg);
	}
};

UILibraryComponents(application);

application.mount('#app');
