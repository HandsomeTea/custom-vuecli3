import axios, { InternalAxiosRequestConfig, AxiosResponse, AxiosError, Method, AxiosInstance } from 'axios';
import Agent from 'agentkeepalive';
import store from '@/store';

class Exception extends Error {
	status: number;
	type?: string | undefined;
	error: Record<string, unknown>;
	httpInfo: string;

	constructor(error: HttpException) {
		super(error.httpInfo);

		this.status = error.status;
		this.type = error.type;
		this.error = error.error || {};
		this.httpInfo = error.httpInfo;
	}
}

interface RestHttpArgument {
	params?: Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
	data?: Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
	headers?: Record<string, string | string[] | number | boolean | null>;
}

class BaseRestApi {
	public Service: AxiosInstance;
	constructor(baseURL?: string) {
		this.Service = this.createService(baseURL);
		this.init();
	}

	createService(baseURL?: string): AxiosInstance {
		return axios.create({
			timeout: 60 * 1000,
			baseURL,
			httpAgent: new Agent({
				keepAlive: true,
				timeout: 60000,
				freeSocketTimeout: 30000,
				freeSocketKeepAliveTimeout: 10,
				socketActiveTTL: 100
			}),
			headers: {
				'x-sensetime-user': store.state.user.account,
				'x-sensetime-userid': store.state.user.userId,
				'x-sensetime-token': store.state.user.token,
				'X-sensetime-role': store.state.user.role
			}
		});
	}

	private init(): void {
		this.Service.interceptors.request.use(config => this.beforeSendToServer(config), this.beforeSendToServerButError);
		this.Service.interceptors.response.use(this.receiveSuccessResponse, this.receiveResponseNotSuccess);
	}

	private beforeSendToServer(config: InternalAxiosRequestConfig): InternalAxiosRequestConfig {
		const zh = config.url?.match(/[\u4e00-\u9fa5]/g);

		if (zh) {
			const _obj: Record<string, string> = {};

			for (let i = 0; i < zh.length; i++) {
				if (!_obj[zh[i]]) {
					_obj[zh[i]] = encodeURIComponent(zh[i]);
				}
			}

			for (const key in _obj) {
				config.url = config.url?.replace(new RegExp(key, 'g'), _obj[key]);
			}
		}

		config.params = {
			...config.params,
			t: Date.now()
		};

		return config;
	}

	private async beforeSendToServerButError(error: unknown): Promise<HttpException> {
		return Promise.reject(
			new Exception({
				httpInfo: `${error}`,
				status: 0,
				error: {
					info: 'request send error: not send.'
				}
			})
		);
	}

	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	private async receiveSuccessResponse(response: AxiosResponse): Promise<any> {
		const { data } = response;

		return Promise.resolve(data);
	}

	private async receiveResponseNotSuccess(error: AxiosError): Promise<HttpException> {
		const { response, config, request: { responseURL } } = error;

		let errorResult: HttpException = {
			status: 500,
			httpInfo: ` 访问 ${config ? config.baseURL : responseURL} 失败`,
			error: { info: '' }
		};

		if (response) {
			const { status, statusText, data } = response;

			try {
				errorResult = {
					status,
					// eslint-disable-next-line @typescript-eslint/ban-ts-comment
					// @ts-ignore
					type: data.code || 'INTERNAL_SERVER_ERROR',
					// eslint-disable-next-line @typescript-eslint/ban-ts-comment
					// @ts-ignore
					httpInfo: data.msg || statusText,
					// eslint-disable-next-line @typescript-eslint/ban-ts-comment
					// @ts-ignore
					error: data.data
				};
			} catch (e) {
				errorResult = {
					status,
					type: 'INTERNAL_SERVER_ERROR',
					httpInfo: statusText,
					// eslint-disable-next-line @typescript-eslint/ban-ts-comment
					// @ts-ignore
					error: { info: data }
				};
			}
		}

		return Promise.reject(new Exception(errorResult));
	}

	private async send(url: string, method: Method, options?: RestHttpArgument): Promise<AxiosResponse> {
		return await this.Service.request({
			url,
			method,
			...options
		});
	}

	public async post(url: string, options: RestHttpArgument): Promise<AxiosResponse> {
		return await this.send(url, 'post', options);
	}

	public async delete(url: string, options?: RestHttpArgument): Promise<AxiosResponse> {
		return await this.send(url, 'delete', options);
	}

	public async put(url: string, options: RestHttpArgument): Promise<AxiosResponse> {
		return await this.send(url, 'put', options);
	}

	public async get(url: string, options?: RestHttpArgument): Promise<AxiosResponse> {
		return await this.send(url, 'get', options);
	}
}

export const HTTP = new class CppBuildRestApi extends BaseRestApi {
	constructor() {
		super(process.env.VUE_APP_DEPLOY_DOMAIN);
	}
};

export const StreamService = new class FileRestApi {
	public async post(url: string, data: Record<string, unknown>) {
		return await fetch(`${process.env.VUE_APP_DEPLOY_DOMAIN}${url}`, {
			method: 'post',
			// eslint-disable-next-line @typescript-eslint/ban-ts-comment
			// @ts-ignore
			timeout: Infinity,
			// eslint-disable-next-line @typescript-eslint/ban-ts-comment
			// @ts-ignore
			body: JSON.stringify(data),
			// eslint-disable-next-line @typescript-eslint/ban-ts-comment
			// @ts-ignore
			headers: {
				'Content-Type': 'application/json',
				'x-sensetime-user': store.state.user.account,
				'x-sensetime-userid': store.state.user.userId,
				'x-sensetime-token': store.state.user.token,
				'X-sensetime-role': store.state.user.role
			},
			responseType: 'stream'
		});
	}
	public async download(url: string, method: Method, query?: Record<string, unknown>) {
		let queryString = '';

		if (query) {
			queryString = Object.keys(query).map(key => `${key}=${encodeURIComponent(query[key] as string)}`).join('&');
		}

		return await fetch(`${process.env.VUE_APP_DEPLOY_DOMAIN}${url}?${queryString}`, {
			method,
			// eslint-disable-next-line @typescript-eslint/ban-ts-comment
			// @ts-ignore
			timeout: Infinity,
			// eslint-disable-next-line @typescript-eslint/ban-ts-comment
			// @ts-ignore
			headers: {
				'x-sensetime-user': store.state.user.account,
				'x-sensetime-userid': store.state.user.userId,
				'x-sensetime-token': store.state.user.token,
				'X-sensetime-role': store.state.user.role
			}
		});
	}
};
