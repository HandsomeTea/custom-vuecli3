// import { HTTP, StreamService } from './http';

class Base {
	public errorHandle(error: HttpException): Promise<ApiResult> {
		return Promise.resolve({ error });
	}

	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	public successHandle(data: any): Promise<ApiResult> {
		return Promise.resolve({ data });
	}
}

export const Package = new class Package extends Base {

};
