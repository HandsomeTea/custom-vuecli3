declare module '*.vue' {
  import { DefineComponent } from 'vue';
  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/ban-types
  const component: DefineComponent<{}, {}, any>;

  export default component;
}

declare module '*.png' {
  export default string;
}

type SupportLanguageType = 'zh-cn' | 'en';

declare interface HttpException {
  httpInfo: string;
  status: number;
  type?: string;
  error?: Record<string, unknown>;
}

declare interface ApiResult {
  data?: any; // eslint-disable-line @typescript-eslint/no-explicit-any
  error?: HttpException;
}
