import { createRouter, createWebHistory, RouteRecordRaw, createWebHashHistory, RouteLocationNormalized, NavigationGuardNext, RouteLocationNormalizedLoaded } from 'vue-router';
import store from '@/store';
import { Tips } from '@/ui-frame';

const routes: Array<RouteRecordRaw> = [{
	path: '/',
	redirect: '/index'
}, {
	path: '/login',
	meta: { title: 'internal-ops', page: 'login' },
	component: () => import(/* webpackChunkName: 'login' */ '../views/login.vue')
}, {
	path: '/view',
	redirect: '/index',
	component: () => import(/* webpackChunkName: 'layout' */ '../views/layout/index.vue'),
	children: [{
		path: '/index',
		meta: { title: '首页', page: 'index' },
		component: () => import(/* webpackChunkName: 'home' */ '../views/home.vue')
	}, {
		path: '/test',
		meta: { title: '测试', page: 'test' },
		component: () => import(/* webpackChunkName: 'home' */ '../views/test.vue')
	}]
}];

const router = createRouter({
	history: process.env.NODE_ENV === 'development' ? createWebHashHistory(process.env.BASE_URL) : createWebHistory(process.env.BASE_URL),
	routes
});

router.beforeEach((to: RouteLocationNormalized, from: RouteLocationNormalized, next: NavigationGuardNext) => {
	if (to.path !== '/login') {
		if (!store.state.user.isLogin) {
			Tips.warn('需要登录');
			return;
		}
	} else if (store.state.user.isLogin) {
		return next('/index');
	}
	next();
});

router.afterEach((to: RouteLocationNormalized, from: RouteLocationNormalizedLoaded) => {
	document.title = to.meta.title as string || 'templates';
});

export default router;
