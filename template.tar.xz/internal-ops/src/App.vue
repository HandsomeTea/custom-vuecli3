<template>
	<a-config-provider :locale="locale">
		<router-view />
	</a-config-provider>
</template>
<script lang="ts" setup>
import { computed, onMounted } from 'vue';
import { Store, useStore } from 'vuex';
import { RootState } from '@/store/stateModel';
import { getCacheLoginInfo, redirectTo } from '@/views/lib';

import zhCN from '@arco-design/web-vue/es/locale/lang/zh-cn';
import enUS from '@arco-design/web-vue/es/locale/lang/en-us';
import { ArcoLang } from '@arco-design/web-vue/es/locale/interface';

const store: Store<RootState> = useStore();
const languageMap: Record<SupportLanguageType, ArcoLang> = {
	'en': enUS,
	'zh-cn': zhCN
};

const locale = computed(() => {
	return languageMap[store.state.language] || zhCN;
});

onMounted(async () => {
	const { username, token } = getCacheLoginInfo();

	if (username && token) {
		const result = await store.dispatch('user/login', {
			username,
			token
		}) as boolean;

		if (result) {
			redirectTo('/index');
		}
	} else {
		redirectTo('/login');
	}
});

</script>
