export const random = () => Math.random().toString(36).substring(2);

export const getFileBase64 = async (file: File): Promise<string> => {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();

		reader.readAsDataURL(file);
		reader.onload = () => resolve(reader.result as string);
		reader.onerror = error => reject(error);
	});
};

import ClipboardJS from 'clipboard';

export const copyText = async (text: string, bindEleId: string): Promise<boolean> => {
	return await new Promise(resolve => {
		let clipboard: ClipboardJS | null = new ClipboardJS(`#${bindEleId}`, {
			text: () => text
		});

		clipboard.on('success', (e) => {
			e.clearSelection();
			resolve(true);
			clipboard?.destroy();
			clipboard = null;
		});
		clipboard.on('error', () => {
			resolve(false);
		});
	});
};


// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const getFormValidateResult = async (formRef: any): Promise<boolean> => {
	return await new Promise(resolve => {
		formRef.validate((error: unknown) => {
			if (error) {
				resolve(false);
			}
			resolve(true);
		});
	});
};
