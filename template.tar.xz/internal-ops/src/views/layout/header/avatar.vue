<template>
    <a-dropdown-button>
        <span class="text-[14px]">
            <icon-user class="text-[#3370ff] text-[18px]" />&nbsp;liuhaifeng
        </span>
        <template #icon>
            <icon-down />
        </template>
        <template #content>
            <a-doption>{{ $t('layout.header.settings') }}</a-doption>
            <a-dsubmenu value="option-1">
                <template #default>
                    语言
                </template>
                <template #content>
                    <a-doption @click="changeLanguage('zh-cn')" :class="[{ 'text-[#3370ff]': locale === 'zh-cn' }]">
                        简体中文
                    </a-doption>
                    <a-doption @click="changeLanguage('en')" :class="[{ 'text-[#3370ff]': locale === 'en' }]">
                        英文
                    </a-doption>
                </template>
            </a-dsubmenu>
            <a-doption class="text-red-500" @click="logout()">
                退出登录
            </a-doption>
        </template>
    </a-dropdown-button>
</template>

<script lang="ts" setup>
import { Store, useStore } from 'vuex';
import { RootState } from '@/store/stateModel';
import { redirectTo } from '@/views/lib';

import { useI18n } from 'vue-i18n';


const { locale } = useI18n();
const store: Store<RootState> = useStore();
const logout = async () => {
    await store.dispatch('user/logout');
    redirectTo('/login');
};
const changeLanguage = (lang: SupportLanguageType) => {
    store.dispatch('changeLanguage', lang);
    locale.value = lang;
};

</script>
