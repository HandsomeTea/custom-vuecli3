<template>
	<a-page-header class="bg-white shadow-sm py-[12px]" @back="() => $router.back()">
		<template #title>
			<breadcrumb />
		</template>
		<template #subtitle>
			模型转换
		</template>
		<template #extra>
			<avatar />
		</template>
	</a-page-header>
</template>

<script lang="ts">
import { defineComponent, defineAsyncComponent } from 'vue';

export default defineComponent({
	components: {
		breadcrumb: defineAsyncComponent(() => import(/* webpackChunkName: 'layout' */ './breadcrumb.vue')),
		avatar: defineAsyncComponent(() => import(/* webpackChunkName: 'layout' */ './avatar.vue'))
	}
});
</script>
