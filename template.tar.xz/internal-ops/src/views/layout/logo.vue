<template>
	<p class="flex items-center">
		<img
			src="../../assets/image/logo.png"
			alt="logo"
			width="32px"
			height="32px"
			class="ml-[8px]"
		>
		<span v-if="!isHideMenu" class="ml-[10px]">logo</span>
	</p>
</template>

<script lang="ts" setup>
import { getMenuStatus } from '@/views/lib';

const isHideMenu = getMenuStatus();

</script>
