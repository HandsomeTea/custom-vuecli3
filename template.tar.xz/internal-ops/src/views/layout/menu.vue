<template>
	<a-menu theme="dark" breakpoint="xl" show-collapse-button auto-open-selected v-model:selected-keys="activeMenu"
		class="bg-transparent" @collapse="toogleMenu" @menu-item-click="changeRoute">
		<a-sub-menu key="0">
			<template #icon>
				<icon-apps />
			</template>
			<template #title>
				Navigation 1
			</template>
			<a-menu-item key="index">
				首页
			</a-menu-item>
			<a-menu-item key="test">
				测试页面
			</a-menu-item>
			<a-menu-item key="0_2">
				Menu 3
			</a-menu-item>
			<a-menu-item key="0_3">
				Menu 4
			</a-menu-item>
		</a-sub-menu>
		<a-sub-menu key="1">
			<template #icon>
				<icon-bug />
			</template>
			<template #title>
				Navigation 2
			</template>
			<a-menu-item key="1_0">
				Menu 1
			</a-menu-item>
			<a-menu-item key="1_1">
				Menu 2
			</a-menu-item>
			<a-menu-item key="1_2">
				Menu 3
			</a-menu-item>
		</a-sub-menu>
		<a-sub-menu key="2">
			<template #icon>
				<icon-bulb />
			</template>
			<template #title>
				Navigation 3
			</template>
			<a-menu-item key="2_0">
				Menu 1
			</a-menu-item>
			<a-menu-item key="2_1">
				Menu 2
			</a-menu-item>
			<a-sub-menu key="2_2" title="Navigation 4">
				<a-menu-item key="2_2_0">
					Menu 1
				</a-menu-item>
				<a-menu-item key="2_2_1">
					Menu 2
				</a-menu-item>
			</a-sub-menu>
		</a-sub-menu>
	</a-menu>
</template>

<script lang="ts" setup>
import { redirectTo } from '@/views/lib';
import { Store, useStore } from 'vuex';
import { RootState } from '@/store/stateModel';
import { ref, watch } from 'vue';
import router from '@/router';

const activeMenu = ref([router.currentRoute.value.matched[1].meta.page]);

watch(() => router.currentRoute.value, () => {
	activeMenu.value = [router.currentRoute.value.matched[1].meta.page];
}, { immediate: true, deep: true });

const store: Store<RootState> = useStore();
const toogleMenu = (status: boolean) => {
	store.dispatch('toogleSideShrink', status);
};
const changeRoute = (page: string) => {
	const route = router.getRoutes().find(a => a.meta.page === page);

	if (route) {
		redirectTo(route.path);
	}
};

</script>
