<template>
	<a-row class="view-container">
		<a-col :flex="isHideMenu ? '48px' : '220px'" class="view-aside">
			<logo class="h-[55px] overflow-hidden" />
			<navigation-menu class="h-[calc(100%-55px)] overflow-hidden" />
		</a-col>
		<a-col flex="auto" class="h-full">
			<page-header />
			<div
				class="view-main p-0 my-[16px] mx-[20px] w-[calc(100%-40px)] h-[calc(100%-87px)] overflow-auto rounded-[6px]"
			>
				<router-view />
			</div>
		</a-col>
	</a-row>
</template>


<script lang="ts">
import { defineComponent, defineAsyncComponent } from 'vue';
import { getMenuStatus } from '@/views/lib';

export default defineComponent({
	components: {
		navigationMenu: defineAsyncComponent(() => import(/* webpackChunkName: 'layout' */ './menu.vue')),
		logo: defineAsyncComponent(() => import(/* webpackChunkName: 'layout' */ './logo.vue')),
		pageHeader: defineAsyncComponent(() => import(/* webpackChunkName: 'layout' */ './header/index.vue'))
	},
	setup() {
		return {
			isHideMenu: getMenuStatus()
		};
	}
});
</script>

<style lang="less">
.view-container {
	width: 100%;
	height: 100%;
	background-color: #fbfbfb;
	color: #666;
}

.view-aside {
	transition: all 0.2s;
	background-color: rgb(22, 24, 29);
	border-right: solid 1px #e6e6e6;
	overflow: hidden;
	height: 100%;
}

.view-main {
	background-color: #fff;
	box-shadow: 0 4px 6px 0px rgba(0, 0, 0, 0.1), 0px -1px 6px -2px rgba(0, 0, 0, 0.1);
}
</style>
