<template>
	<a-card class="w-[300px] mx-auto mt-[200px]">
		<template #title>
			<p class="text-center">
				登录
			</p>
		</template>
		<a-input
			v-model="username"
			class="w-[268px]"
			placeholder="用户名"
			allow-clear
		>
			<template #prefix>
				<icon-user />
			</template>
		</a-input>
		<a-input-password
			v-model="password"
			class="w-[268px] mt-[20px]"
			placeholder="密码"
			allow-clear
		>
			<template #prefix>
				<icon-lock />
			</template>
		</a-input-password>
		<a-button type="primary" class="w-[268px] mt-[20px]" @click="login()">
			登录
		</a-button>
	</a-card>
</template>

<script lang="ts" setup>
import { ref } from 'vue';
import { Store, useStore } from 'vuex';
import { RootState } from '@/store/stateModel';
import { redirectTo } from '@/views/lib';


const store: Store<RootState> = useStore();
const username = ref('example@company.com');
const password = ref('12345678');
const login = async () => {
	await store.dispatch('user/login', {
		username: username.value,
		password: password.value
	});
	redirectTo('/index');
};

</script>
