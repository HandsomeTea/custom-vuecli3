<template>
	<div>
		index <a-pagination
			:total="50"
			show-total
			show-jumper
			show-page-size
			style="margin-top: 20px; margin-bottom: 20px;"
		/>
	</div>
</template>
