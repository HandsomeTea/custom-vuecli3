import { computed, ComputedRef } from 'vue';
import { Store, useStore } from 'vuex';
import { RootState, UserState } from '@/store/stateModel';
import router from '@/router';
import { LocationQueryRaw } from 'vue-router';


export const getMenuStatus = (): ComputedRef<boolean> => {
	const store: Store<RootState> = useStore();

	return computed(() => store.state.menuHidden);
};

export const getLoginStatus = (): ComputedRef<boolean> => {
	const store: Store<RootState> = useStore();

	return computed(() => store.getters.loginStatus);
};

export const getLoginUserInfo = (): ComputedRef<Partial<UserState>> => {
	const store: Store<RootState> = useStore();

	return computed(() => store.state.user);
};

export const redirectTo = (path: string, query?: LocationQueryRaw): void => {
	if (path !== router.currentRoute.value.path) {
		router.push({
			path,
			query
		});
	}
};

export const getCacheLoginInfo = () => {
	const username = localStorage.getItem('username');
	const token = localStorage.getItem('token');

	return {
		username,
		token
	};
};

export const setCacheLoginInfo = (username: string, token: string) => {
	localStorage.setItem('username', username);
	localStorage.setItem('token', token);
};

export const removeCacheLoginInfo = () => {
	localStorage.removeItem('username');
	localStorage.removeItem('token');
};
