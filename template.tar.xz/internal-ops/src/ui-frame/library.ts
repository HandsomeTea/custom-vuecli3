import { App } from 'vue';
import '@arco-design/web-vue/dist/arco.css';
import {
	IconMenuFold, IconMenuUnfold, IconApps, IconBulb,
	IconBug, IconUser, IconDown, IconLock, IconCheck
} from '@arco-design/web-vue/es/icon';

export default (app: App<Element>): void => {
	app.use(IconMenuFold);
	app.use(IconMenuUnfold);
	app.use(IconApps);
	app.use(IconBulb);
	app.use(IconBug);
	app.use(IconUser);
	app.use(IconDown);
	app.use(IconLock);
	app.use(IconCheck);
};
