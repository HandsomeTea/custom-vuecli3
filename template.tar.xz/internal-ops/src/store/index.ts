import { createStore } from 'vuex';
import { RootState } from './stateModel';
import user from './user';
import getters from './getters';

const state: RootState = {
	language: window.navigator.language.toLowerCase() as SupportLanguageType,
	menuHidden: false,
	user: {}
};

const store = createStore({
	state,
	getters,
	modules: {
		user
	},
	mutations: {
		_toogleSideShrink(state: RootState, status?: boolean) {
			if (typeof status !== 'undefined') {
				state.menuHidden = status;
			} else {
				state.menuHidden = !state.menuHidden;
			}
		},
		_changeLanguage(state: RootState, language: SupportLanguageType) {
			state.language = language;
			window.localStorage.setItem('language', language);
		}
	},
	actions: {
		toogleSideShrink({ commit }, status?: boolean) {
			commit('_toogleSideShrink', status);
		},
		changeLanguage({ commit }, language: SupportLanguageType) {
			commit('_changeLanguage', language);
		}
	}
});

export default store;
