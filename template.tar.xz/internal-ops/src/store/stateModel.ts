export interface UserState {
    userId: string
    account: string
    role: string
    token: string
    isLogin: boolean
}

export interface RootState {
    language: SupportLanguageType;
    menuHidden: boolean;
    user: Partial<UserState>
}
