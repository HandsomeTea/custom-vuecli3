import { MutationTree, ActionTree, Module } from 'vuex';
import { RootState, UserState } from './stateModel';
import { setCacheLoginInfo, removeCacheLoginInfo } from '@/views/lib';


const state: UserState = {
	userId: '',
	account: '',
	role: '',
	token: '',
	isLogin: false
};
const mutations: MutationTree<UserState> = {
	_login(state: UserState, _user: { username: string, password?: string, token?: string }) {
		const loginResult = {
			userId: '5004',
			account: _user.username,
			role: 'admin',
			token: 'd459c17f4cf5090e'
		};

		state.userId = loginResult.userId;
		state.account = loginResult.account;
		state.role = loginResult.role;
		state.token = loginResult.token;
		state.isLogin = true;
		setCacheLoginInfo(state.account, state.token);
	},
	_logout() {
		state.userId = '';
		state.account = '';
		state.role = '';
		state.token = '';
		state.isLogin = false;
		removeCacheLoginInfo();
	}
};

const actions: ActionTree<UserState, RootState> = {
	login({ commit }, user: { username: string, password?: string, token?: string }) {
		if (!user.token && !user.password) {
			return false;
		}
		commit('_login', user);

		return true;
	},
	async logout({ commit }) {
		commit('_logout');
	}
};

const user: Module<UserState, RootState> = {
	namespaced: true,
	state,
	mutations,
	actions
};

export default user;
