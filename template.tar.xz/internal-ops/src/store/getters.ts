import { RootState } from './stateModel';

export default {
	loginStatus: (state: RootState): boolean => {
		return Boolean(state.user?.userId);
	}
};
