import { createI18n } from 'vue-i18n';

import zhCn from './locale/zh-cn.json';
import zhCnErrorCode from './errorCode/zh-cn.json';
import en from './locale/en.json';
import enErrorCode from './errorCode/en.json';
import store from '@/store';

const i18n = createI18n({
	legacy: false,
	locale: store.state.language,
	messages: {
		'zh-cn': { ...zhCn, ...zhCnErrorCode },
		en: { ...en, ...enErrorCode }
	}
});

export default i18n;
