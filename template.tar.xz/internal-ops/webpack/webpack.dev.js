/* eslint-disable @typescript-eslint/no-var-requires */
const { merge } = require('webpack-merge');
const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin');
const common = require('./webpack.common');

module.exports = merge(common, {
	mode: 'development',
	cache: true,
	devtool: 'eval-source-map',
	watchOptions: {
		ignored: /node_modules/,
	},
	plugins: [
		new ForkTsCheckerWebpackPlugin()
	],
	devServer: {
		port: 3584,
		headers: {},
		open: true,
		https: false,
		headers: {
			'Access-Control-Allow-Origin': '*'
		},
		proxy: {
			'/api/cppbuildci/': {
				target: 'http://localhost:3581',
				// target: 'http://test.adela.sensetime.com',
				changeOrigin: true
			},
			'/api/cppbuild/': {
				target: 'http://localhost:3582',
				// target: 'http://test.adela.sensetime.com',
				changeOrigin: true
			},
			'/api/cppbuildclishortcut/': {
				target: 'http://localhost:3582',
				// target: 'http://test.adela.sensetime.com',
				changeOrigin: true
			}
		}
	}
});
