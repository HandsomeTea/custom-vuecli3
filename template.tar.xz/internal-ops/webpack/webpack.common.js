const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const AutoImport = require('unplugin-auto-import/webpack');
const webpack = require('webpack');
const Components = require('unplugin-vue-components/webpack');
const { ArcoResolver } = require('unplugin-vue-components/resolvers');
const packageName = require('../package.json').name;

module.exports = {
	output: {
		library: `${packageName}-[name]`,
		libraryTarget: 'umd',
		chunkLoadingGlobal: `webpackJsonp_${packageName}`
	},
	target: 'web',
	plugins: [
		new webpack.DefinePlugin({
			__VUE_PROD_HYDRATION_MISMATCH_DETAILS__: 'false'
		}),
		new CleanWebpackPlugin(),
		AutoImport({
			resolvers: [
				ArcoResolver({ importStyle: false })
			]
		}),
		Components({
			resolvers: [
				ArcoResolver({ importStyle: false })
			]
		})
	],
	optimization: {
		runtimeChunk: 'single',
		minimize: true
	},
	module: {
		rules: [{
			test: /\.(css|less)$/,
			use: ['postcss-loader']
		}, {
			test: /\.(png|jpe?g|gif|eot|svg|tff|woff|woff2|webp)(\?.*)?$/,
			type: 'asset/resource',
			generator: {
				filename: 'image/[name].[hash:8].[ext]'
			}
		}]
	}
};
