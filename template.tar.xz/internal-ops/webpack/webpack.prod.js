/* eslint-disable @typescript-eslint/no-var-requires */
const { merge } = require('webpack-merge');
const common = require('./webpack.common');
const webpack = require('webpack');
const vendorPackage = [
	'vue', 'vue-i18n', 'vue-router', 'vuex',
	'@arco-design/web-vue',
	'axios', 'lodash', 'cytoscape'
];
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
const isTestBuild = process.argv.includes('-build-view');
const catchPackagesGrouped = () => {
	const result = {};

	vendorPackage.map(package => {
		result[package] = {
			test: module => {
				return module.resource && module.resource.includes(`/node_modules/${package}/`);
			},
			name: package,
			minSize: 0,
			priority: 120,
			maxInitialRequests: 10,
			chunks: 'all',
			minChunks: 1
		};
	});

	return result;
};

module.exports = merge(common, {
	mode: 'production',
	devtool: 'source-map',
	stats: 'errors-only',
	optimization: {
		concatenateModules: true,
		splitChunks: {
			chunks: 'all',
			cacheGroups: {
				...catchPackagesGrouped()
			}
		}
	},
	plugins: [
		new webpack.LoaderOptionsPlugin({
			options: {
				productionGzip: true
			}
		}),
		new webpack.ids.HashedModuleIdsPlugin({
			hashFunction: 'sha256',
			hashDigest: 'hex',
			hashDigestLength: 20
		}),
		...isTestBuild ? [new BundleAnalyzerPlugin({ analyzerHost: '0.0.0.0', analyzerPort: 8889 })] : []
	]
});
